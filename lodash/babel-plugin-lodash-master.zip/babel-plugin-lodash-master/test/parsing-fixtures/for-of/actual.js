for (const a of b) {}
