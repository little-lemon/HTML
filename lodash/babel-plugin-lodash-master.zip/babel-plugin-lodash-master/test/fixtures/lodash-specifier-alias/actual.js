import { map as map2 } from 'lodash';

map2([]);
