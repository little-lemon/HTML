import { filter, identity, map, noop } from 'lodash';

identity || noop;
noop ? map : filter;
noop;
