'use strict';

var _map2 = require('lodash/fp/map');

var _map3 = _interopRequireDefault(_map2);

var _head2 = require('lodash/fp/head');

var _head3 = _interopRequireDefault(_head2);

var _compose2 = require('lodash/fp/compose');

var _compose3 = _interopRequireDefault(_compose2);

var _capitalize2 = require('lodash/fp/capitalize');

var _capitalize3 = _interopRequireDefault(_capitalize2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _compose3.default)((0, _map3.default)(_capitalize3.default), _head3.default)([]);
