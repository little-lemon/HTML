import _ from 'lodash';
import fp from 'lodash/fp';

_.merge({}, ...args);
fp.merge({}, ...args);
