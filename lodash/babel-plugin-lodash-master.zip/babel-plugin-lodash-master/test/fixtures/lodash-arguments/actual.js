import { capitalize, map } from 'lodash';

map([], capitalize);
