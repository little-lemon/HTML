import _ from 'lodash-compat';

_.identity || _.noop;
_.noop ? _.map : _.filter;
_.noop;
