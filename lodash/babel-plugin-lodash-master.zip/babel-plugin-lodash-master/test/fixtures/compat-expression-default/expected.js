'use strict';

var _filter2 = require('lodash-compat/collection/filter');

var _filter3 = _interopRequireDefault(_filter2);

var _map2 = require('lodash-compat/collection/map');

var _map3 = _interopRequireDefault(_map2);

var _noop2 = require('lodash-compat/utility/noop');

var _noop3 = _interopRequireDefault(_noop2);

var _identity2 = require('lodash-compat/utility/identity');

var _identity3 = _interopRequireDefault(_identity2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_identity3.default || _noop3.default;
_noop3.default ? _map3.default : _filter3.default;
_noop3.default;
