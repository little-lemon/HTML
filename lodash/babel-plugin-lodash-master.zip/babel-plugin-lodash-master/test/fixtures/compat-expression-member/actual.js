import { filter, identity, map, noop } from 'lodash-compat';

identity || noop;
noop ? map : filter;
noop;
