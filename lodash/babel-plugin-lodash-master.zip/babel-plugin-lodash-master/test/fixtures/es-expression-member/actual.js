import { filter, identity, map, noop } from 'lodash-es';

identity || noop;
noop ? map : filter;
noop;
