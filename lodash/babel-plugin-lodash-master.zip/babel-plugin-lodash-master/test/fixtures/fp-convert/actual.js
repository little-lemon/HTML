import { filter, map } from 'lodash';
import convert from 'lodash-fp/convert';

const fp = convert({
  filter, map
});
