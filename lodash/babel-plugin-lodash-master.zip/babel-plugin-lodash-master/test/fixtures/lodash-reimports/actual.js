import { map as map2 } from 'lodash';
import { map as map3 } from 'lodash';
import _ from 'lodash';
import l from 'lodash';

const result1 = map2([]);
const result2 = map3([]);
const result3 = _.map([]);
const result4 = l.map([]);
