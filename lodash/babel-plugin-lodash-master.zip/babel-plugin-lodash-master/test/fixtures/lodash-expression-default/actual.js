import _ from 'lodash';

_.identity || _.noop;
_.noop ? _.map : _.filter;
_.noop;
