import { bind } from 'lodash';

bind.placeholder = {};
