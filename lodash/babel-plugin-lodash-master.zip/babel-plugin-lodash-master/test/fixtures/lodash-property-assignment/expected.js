'use strict';

var _bind2 = require('lodash/bind');

var _bind3 = _interopRequireDefault(_bind2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_bind3.default.placeholder = {};
