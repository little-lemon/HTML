import { isObject as foo } from 'lodash';

isObject(a);

export { foo };
export { isObject } from 'lodash';
export { map } from 'lodash/fp';
export { default as bar } from 'foo';
