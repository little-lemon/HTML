import { capitalize, map } from 'lodash-compat';

map([], capitalize);
