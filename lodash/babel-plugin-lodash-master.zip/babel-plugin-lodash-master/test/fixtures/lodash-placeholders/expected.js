'use strict';

var _bind2 = require('lodash/bind');

var _bind3 = _interopRequireDefault(_bind2);

var _partial2 = require('lodash/fp/partial');

var _partial3 = _interopRequireDefault(_partial2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _bind3.default)(func, _bind3.default.placeholder, 1);
(0, _partial3.default)(func, _partial3.default.placeholder, 1);
