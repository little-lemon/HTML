import { filter, identity, map, noop } from 'lodash/fp';

identity || noop;
noop ? map : filter;
noop;
