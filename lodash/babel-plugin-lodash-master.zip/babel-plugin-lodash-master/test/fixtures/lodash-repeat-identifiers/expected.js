'use strict';

var _noop2 = require('lodash/noop');

var _noop3 = _interopRequireDefault(_noop2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var array = [undefined, undefined, _noop3.default, _noop3.default, _noop3.default, _noop3.default];

(0, _noop3.default)(_noop3.default.placeholder, _noop3.default.placeholder, _noop3.default, _noop3.default, _noop3.default, _noop3.default);
