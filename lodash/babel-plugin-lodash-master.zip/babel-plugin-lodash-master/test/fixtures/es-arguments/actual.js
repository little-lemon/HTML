import { capitalize, map } from 'lodash-es';

map([], capitalize);
