'use strict';

var _map2 = require('lodash-es/map');

var _map3 = _interopRequireDefault(_map2);

var _capitalize2 = require('lodash-es/capitalize');

var _capitalize3 = _interopRequireDefault(_capitalize2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _map3.default)([], _capitalize3.default);
