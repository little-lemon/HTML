import _ from 'lodash';
import { map } from 'lodash';

const result1 = map([]);
const result2 = _.map([]);
const result3 = map([]);
const result4 = _.map([]);
