import _ from 'lodash/fp';

_.identity || _.noop;
_.noop ? _.map : _.filter;
_.noop;
