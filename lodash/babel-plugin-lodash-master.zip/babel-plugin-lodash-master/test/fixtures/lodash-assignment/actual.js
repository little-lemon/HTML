import { noop } from 'lodash';

const o = {};
o.a = noop;
