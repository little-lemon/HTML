import { noop } from 'lodash';

<div onClick={ noop } />;
