'use strict';

var _noop2 = require('lodash/noop');

var _noop3 = _interopRequireDefault(_noop2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

<div onClick={_noop3.default} />;
