import type { Predicate } from 'lodash';

function a(b: Predicate<*>) {}
