'use strict';

function a(b: Predicate<*>) {}
