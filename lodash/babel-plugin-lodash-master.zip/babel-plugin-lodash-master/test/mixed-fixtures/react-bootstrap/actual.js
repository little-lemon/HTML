import { Alert } from 'react-bootstrap';

<Alert />
