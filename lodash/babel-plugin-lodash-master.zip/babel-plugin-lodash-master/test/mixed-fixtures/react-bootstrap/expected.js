'use strict';

var _Alert2 = require('react-bootstrap/lib/Alert');

var _Alert3 = _interopRequireDefault(_Alert2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

React.createElement(_Alert3.default, null);
