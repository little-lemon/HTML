import config from './config';

export default config();
